﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PluginEngine
{
    public class MyPluginType
    {
        public MyPluginType()
        {
        }
 
        public virtual bool Main()
        {
            // By default, this function return a true value.
            return true;
        }

        public virtual string Text { get; set; }
    }
}
