﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace UsingAssemblyDynamically
{
    public partial class Form1 : Form
    {

        // This variable will contains the list of assemblys loaded by button1_Click void.
        System.Collections.Generic.List<System.Reflection.Assembly> ASSEMBLYS = new System.Collections.Generic.List<System.Reflection.Assembly>();

        // This variable will contains the list of instance inherited by PluginEngin.MyPluginType loaded by button2_Click void.
        System.Collections.Generic.List<PluginEngine.MyPluginType> PLUGINS = new System.Collections.Generic.List<PluginEngine.MyPluginType>();



        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // For each .dll file in Plugin folder
            foreach (string file in System.IO.Directory.GetFiles(Application.StartupPath + @"\Plugins\", "*.dll"))
            {
                ASSEMBLYS.Add(System.Reflection.Assembly.LoadFile(file)); // We load the assembly
            }
            this.button1.Enabled = false;
            this.button2.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // For each loaded assembly
            foreach (System.Reflection.Assembly assembly in ASSEMBLYS)
            {
                // For each type of the assembly
                foreach (Type type in assembly.GetTypes())
                {
                    // If the type is inherited by tge type PluginEngine.MyPluginType and is public
                    if (type.IsSubclassOf(typeof(PluginEngine.MyPluginType)) && type.IsPublic)
                    {
                        // We create a new instance of this type and add it in PLUGINS variable
                        PLUGINS.Add((PluginEngine.MyPluginType)assembly.CreateInstance(type.FullName));
                    }
                }
            }
            this.button2.Enabled = false;
            this.button3.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // For each loaded plugin
            foreach (PluginEngine.MyPluginType plugin in PLUGINS)
            {
                plugin.Main(); // We run the Main function. Note that you can get the returned value of this function, it can be practice.
            }
            this.button3.Enabled = false;
            this.button4.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // For each loaded plugin
            foreach (PluginEngine.MyPluginType plugin in PLUGINS)
            {
                System.Windows.Forms.MessageBox.Show(plugin.Text); // We show value of Text property of the plugin in a message.
            }
        }
    }
}
