﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MySecondLibrary
{
    public class Plug2 : PluginEngine.MyPluginType
    {      
        public Plug2()
        {
            System.Windows.Forms.MessageBox.Show("The Plug2 has been loaded !");
        }

        public override bool Main()
        {
            this.Text = "Hello World from MySecondLibrary.Plug2 !";
            return true;
        }
    }
}
