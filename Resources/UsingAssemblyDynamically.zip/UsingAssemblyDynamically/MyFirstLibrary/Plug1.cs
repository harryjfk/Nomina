﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyFirstLibrary
{
    public class Plug1 : PluginEngine.MyPluginType 
    {
        public Plug1()
        {
            System.Windows.Forms.MessageBox.Show("Plug1 is loaded");
        }

        public override bool Main()
        {
            this.Text = "Hello World from MyFirstLibrary.Plug1 !";
            return true;
        }
    }
}
