//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//

using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.FxCop.Sdk;
using Microsoft.FxCop.Sdk.Introspection;
using Microsoft.Cci;

namespace Microsoft.AddIn.FxCopRules
{
    // 
    // Delegate used to pass methods that "check" a certain type.
    // 
    internal delegate void TypeCheckDelegate(string resolutionName, string memberName, TypeNode type);

    internal static class Utils
    {
        // 
        // Checks whether the type is serializable (has either SerializableAttribute, implements ISerializable, or both).
        // 
        public static bool IsSerializable(this TypeNode type)
        {
            return type.HasSerializableAttribute() || type.IsAssignableTo(SystemTypes.ISerializable);
        }
            
        // 
        // Checks for the serializable attribute.
        // 
        public static bool HasSerializableAttribute(this Microsoft.Cci.TypeNode type)
        {
            return (type.Flags & TypeFlags.Serializable) == TypeFlags.Serializable;
        }

        // 
        // Checks whether the type is a class that can be instantiated.
        // 
        public static bool IsConcreteReferenceType(this TypeNode type)
        {
            return ((type is Class) && !type.IsAbstract);
        }

        // 
        // Checks if the type implements an interface in the given assembly.
        // 
        public static bool ImplementsInterfaceIn(this TypeNode type, AssemblyNode assembly)
        {
            foreach (Interface i in type.Interfaces)
            {
                if (i.DeclaringModule.ContainingAssembly == assembly)
                {
                    return true;
                }
            }
            return false;
        }

        // 
        // Checks if the type inherits an abstract class in the given assembly.
        // It walks the class hierarchy as long as all the parent classes are in the current assembly.
        // 
        public static bool InheritsAbstractClassFrom(this TypeNode type, AssemblyNode assembly)
        {
            // 
            // Start at the type's base class, and walk up the class hierarchy as long as we stay in the same assembly.
            // 
            for (Class currentClass = type.BaseType as Class;
                currentClass != null && currentClass.DeclaringModule.ContainingAssembly == assembly;
                currentClass = currentClass.BaseClass)
            {
                if (currentClass.IsAbstract) // Found an abstract base class.
                {
                    return true;
                }
            }

            return false;
        }

        // 
        // Given a member, finds all the types "used" by it, and calls checkTypeCallback against all types it finds.
        // 
        public static void CheckContractMemberProblems(this Member member, TypeCheckDelegate checkTypeCallback)
        {
            member.CheckMemberProblems(checkTypeCallback,
                type => false); // For contracts, we don't ignore any types.
        }

        // 
        // Given a member, finds all the types "used" by it, and calls checkTypeCallback against all types it finds.
        // 
        public static void CheckViewMemberProblems(this Member member, TypeCheckDelegate checkTypeCallback)
        {
            // For views, we ignore checks on three special types: 
            // * IList<T>
            // * System.Windows.FrameworkElement
            // * System.Windows.Forms.Control
            member.CheckMemberProblems(checkTypeCallback,
                type =>
                type.IsAssignableTo(TypeNode.GetTypeNode(typeof(System.Windows.Forms.Control))) ||
                type.IsAssignableTo(TypeNode.GetTypeNode(typeof(System.Windows.FrameworkElement))) ||
                type.IsAssignableToInstanceOf(SystemTypes.GenericIList));
        }

        // 
        // Given a member, finds all the types "used" by it, and calls checkTypeCallback against all types it finds.
        // 
        private static void CheckMemberProblems(this Member member, TypeCheckDelegate checkTypeCallback, Predicate<TypeNode> ignoreType)
        {
            Field field = member as Field;
            Method method = member as Method;
            Property property = member as Property;

            if (field != null)
            {
                CheckTypeProblems("Field", "'" + field.FullName + "'", field.Type, checkTypeCallback, ignoreType);
            }
            else if (method != null)
            {
                if (!(method.DeclaringMember is Property) && !(method.DeclaringMember is Event))
                {
                    CheckTypeProblems("MethodReturnValue", "'" + method.FullName + "'", method.ReturnType, checkTypeCallback, ignoreType);
                    foreach (Parameter p in method.Parameters)
                    {
                        CheckTypeProblems("MethodParameter", "'" + p.Name.ToString() + "'", p.Type, checkTypeCallback, ignoreType);
                    }
                }
            }
            else if (property != null)
            {
                CheckTypeProblems("Property", "'" + property.FullName + "'", property.Type, checkTypeCallback, ignoreType);
            }
        }


        private static void CheckTypeProblems(string resolutionName, string name, TypeNode type, TypeCheckDelegate checkTypeCallback, Predicate<TypeNode> ignoreType)
        {            
            if(!ignoreType(type))
            {
                checkTypeCallback(resolutionName, name, type);
            }

            if (type.IsGeneric)
            {
                foreach (TypeNode templateArgument in type.TemplateArguments)
                {
                    CheckTypeProblems(resolutionName, name, templateArgument, checkTypeCallback, ignoreType);
                }
            }

            if (type is ArrayType)
            {
                foreach (TypeNode element in type.StructuralElementTypes)
                {
                    CheckTypeProblems(resolutionName, name, element, checkTypeCallback, ignoreType);
                }
            }
        }

        // 
        // Determines if an assembly is a framework assembly by checking its public key token 
        // against three known public key tokens.
        // 
        public static bool IsFrameworkAssembly(this AssemblyNode assembly)
        {
            byte[] frameworkToken1 ={
                              0xb7,
                              0x7a,
                              0x5c,
                              0x56,
                              0x19,
                              0x34,
                              0xe0,
                              0x89};
            byte[] frameworkToken2 ={
                              0xb0,
                              0x3f,
                              0x5f,
                              0x7f,
                              0x11,
                              0xd5,
                              0x0a,
                              0x3a};
            byte[] frameworkToken3 ={
                              0x31,
                              0xbf,
                              0x38,
                              0x56,
                              0xad,
                              0x36,
                              0x4e,
                              0x35};

            if (assembly.PublicKeyToken == null) { return false; }

            // 
            // If we match any token, return true.
            // 
            if (AreEqual(assembly.PublicKeyToken, frameworkToken1) ||
                AreEqual(assembly.PublicKeyToken, frameworkToken2) ||
                AreEqual(assembly.PublicKeyToken, frameworkToken3))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        
        // 
        // Helper method to do a byte-by-byte comparison of byte arrays (used for public key tokens).
        // 
        private static bool AreEqual(byte[] token1, byte[] token2)
        {
            if (token1 == null || token2 == null) { return false; }
            if (token1.Length != token2.Length) { return false; }

            for (int i = 0; i < token1.Length; i++)
            {
                if (token1[i] != token2[i]) { return false; }
            }

            return true;
        }

        // 
        // Check if there are any interfaces in the given interface's parents that don't implement IContract.
        //
        public static bool HasNonIContractParent(this Interface interfaceToCheck)
        {
            // 
            // Check all parent interfaces to see if any of them have something other than IContract as a parent.
            // Don't need a recursive check here since all parent interfaces are visible in the Interface.Interfaces property.
            //
            foreach (Interface i in interfaceToCheck.Interfaces)
            {
                if (!i.IsAssignableTo(TypeNode.GetTypeNode(typeof(System.AddIn.Contract.IContract))))
                {
                    return true;
                }
            }

            return false;
        }
    }
}
