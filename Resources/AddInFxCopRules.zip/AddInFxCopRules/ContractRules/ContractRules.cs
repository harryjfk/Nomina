﻿//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//

using Microsoft.Cci;
using Microsoft.FxCop.Sdk;
using Microsoft.FxCop.Sdk.Introspection;

// 
// For a description of each rule, see the ContractRules.xml file.
// 
namespace Microsoft.AddIn.FxCopRules.ContractRules
{
    class ContractAssembliesShouldNotHaveReferencesToNonFrameworkAssemblies : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ContractAssembliesShouldNotHaveReferencesToNonFrameworkAssemblies()
            : base("ContractAssembliesShouldNotHaveReferencesToNonFrameworkAssemblies",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldNotHaveReferencesToNonFrameworkAssemblies).Assembly)
        {

        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Module module)
        {
            foreach (AssemblyReference reference in module.AssemblyReferences)
            {
                if (!reference.Assembly.IsFrameworkAssembly())
                {
                    this.Problems.Add(new Problem(this.GetResolution(module.Name, reference.Assembly.Name)));
                }
            }

            return this.Problems;
        }
    }

    class ContractTypesThatRepresentAddInsShouldBeMarkedWithTheAddInContractAttribute : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        private TypeNode m_contractAttribute;

        public ContractTypesThatRepresentAddInsShouldBeMarkedWithTheAddInContractAttribute()
            : base("ContractTypesThatRepresentAddInsShouldBeMarkedWithTheAddInContractAttribute",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractTypesThatRepresentAddInsShouldBeMarkedWithTheAddInContractAttribute).Assembly)
        {
        }

        public override void BeforeAnalysis()
        {
            m_contractAttribute = TypeNode.GetTypeNode(typeof(System.AddIn.Pipeline.AddInContractAttribute));
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Module module)
        {
            bool hasAttribute = false;
            foreach (TypeNode type in module.Types)
            {
                // Limiting search to interfaces only.
                if (type is Interface)
                {
                    foreach (AttributeNode attribute in type.Attributes)
                    {
                        if (attribute.Type == m_contractAttribute)
                        {
                            hasAttribute = true;
                        }
                    }
                }
            }

            if (!hasAttribute)
            {
                this.Problems.Add(new Problem(this.GetResolution()));
            }

            return this.Problems;
        }
    }

    class ValueTypesDefinedInAContractAssemblyShouldBeSerializable : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ValueTypesDefinedInAContractAssemblyShouldBeSerializable()
            : base("ValueTypesDefinedInAContractAssemblyShouldBeSerializable",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ValueTypesDefinedInAContractAssemblyShouldBeSerializable).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            if (type.IsValueType && !type.IsSerializable())
            {
                this.Problems.Add(new Problem(this.GetResolution(type.ToString(), type.ToString())));
            }
            
            return this.Problems;
        }
     }

    class ContractInterfacesShouldNotImplementNonIContractInterfaces : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ContractInterfacesShouldNotImplementNonIContractInterfaces()
            : base("ContractInterfacesShouldNotImplementNonIContractInterfaces",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractInterfacesShouldNotImplementNonIContractInterfaces).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            Interface i = type as Interface;
            if (i != null)
            {
                if (i.HasNonIContractParent())
                {
                    this.Problems.Add(new Problem(GetResolution(type.ToString())));
                }
            }

            return this.Problems;
        }
    }
    
    class ContractInterfacesMustImplementIContract : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        private Interface m_IContract;

        public ContractInterfacesMustImplementIContract()
            : base("ContractInterfacesMustImplementIContract",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractInterfacesMustImplementIContract).Assembly)
        {
        }

        public override void BeforeAnalysis()
        {
            m_IContract = TypeNode.GetTypeNode(typeof(System.AddIn.Contract.IContract)) as Interface;
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            Interface i = type as Interface;
            if (i != null)
            {
                if (!i.IsAssignableTo(m_IContract))
                {
                    this.Problems.Add(new Problem(this.GetResolution(i.FullName)));                    
                }
            }
            return this.Problems;
        }
    }

    class ContractAssembliesShouldNotDefineTypesThatDeriveFromMarshalByRefObject : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ContractAssembliesShouldNotDefineTypesThatDeriveFromMarshalByRefObject()
            : base("ContractAssembliesShouldNotDefineTypesThatDeriveFromMarshalByRefObject",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldNotDefineTypesThatDeriveFromMarshalByRefObject).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            if (type.IsAssignableTo(SystemTypes.MarshalByRefObject))
            {
                this.Problems.Add(new Problem(this.GetResolution(type.FullName)));
            }
            return this.Problems;
        }
    }
        
    class ExceptionTypesMustImplementISerializableAndBeMarkedWithTheSerializableAttribute : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ExceptionTypesMustImplementISerializableAndBeMarkedWithTheSerializableAttribute()
            : base("ExceptionTypesMustImplementISerializableAndBeMarkedWithTheSerializableAttribute",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ExceptionTypesMustImplementISerializableAndBeMarkedWithTheSerializableAttribute).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            if (type.IsAssignableTo(SystemTypes.Exception))
            {
                // If either [Serializable] attribute or ISerializable implementation is missing.
                if (!type.HasSerializableAttribute() ||
                    !(type.Interfaces.SearchFor(SystemTypes.ISerializable) != -1))
                {
                    this.Problems.Add(new Problem(this.GetResolution(type.ToString())));
                }
            }
            return this.Problems;
        }
    }
        
    class ContractAssembliesShouldNotDefineStaticTypes : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ContractAssembliesShouldNotDefineStaticTypes()
            : base("ContractAssembliesShouldNotDefineStaticTypes",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldNotDefineStaticTypes).Assembly)
        {
        }

        public override ProblemCollection Check(Module module)
        {
            // The Check(TypeNode) override doesn't visit static classes.
            // Therefore we use the VisitTypeNode override.
            this.VisitModule(module); // Start "visit" on the module. This will visit all types on the module.
            return this.Problems;
        }

        public override TypeNode VisitTypeNode(TypeNode typeNode)
        {
            // Static classes are sealed and abstract, so we use this check. 
            // IsStatic doesn't work on TypeNode like we need it to.
            if (typeNode.IsSealed && typeNode.IsAbstract)
            {
                this.Problems.Add(new Problem(this.GetResolution(typeNode.FullName)));
            }
            return base.VisitTypeNode(typeNode);
        }
    }
        
    class ContractAssembliesShouldNotDefineReferenceTypesOtherThanExceptionTypes : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ContractAssembliesShouldNotDefineReferenceTypesOtherThanExceptionTypes()
            : base("ContractAssembliesShouldNotDefineReferenceTypesOtherThanExceptionTypes",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldNotDefineReferenceTypesOtherThanExceptionTypes).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            if (type is Class)
            {
                if (!type.IsAssignableTo(SystemTypes.Exception))
                {
                    this.Problems.Add(new Problem(this.GetResolution(type.FullName)));
                }
            }
            
            return this.Problems;
        }
    }
        
    class ContractAssembliesShouldNotDefineDelegateTypes : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ContractAssembliesShouldNotDefineDelegateTypes()
            : base("ContractAssembliesShouldNotDefineDelegateTypes",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldNotDefineDelegateTypes).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            if (type is DelegateNode)
            {
                this.Problems.Add(new Problem(this.GetResolution(type.FullName)));
            }
            return this.Problems;
        }
    }
    
    class ContractAssembliesShouldNotDefineExceptionTypes : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ContractAssembliesShouldNotDefineExceptionTypes()
            : base("ContractAssembliesShouldNotDefineExceptionTypes",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldNotDefineExceptionTypes).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            if(type.IsAssignableTo(SystemTypes.Exception))
            {
                this.Problems.Add(new Problem(this.GetResolution(type.FullName)));
            }
            return this.Problems;
        }
    }
        
    class NonExceptionTypesShouldPreferSerializableAttributeOverISerializable : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public NonExceptionTypesShouldPreferSerializableAttributeOverISerializable()
            : base("NonExceptionTypesShouldPreferSerializableAttributeOverISerializable",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(NonExceptionTypesShouldPreferSerializableAttributeOverISerializable).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            if (!type.IsAssignableTo(SystemTypes.Exception))
            {
                if (type.IsAssignableTo(SystemTypes.ISerializable))
                {
                    this.Problems.Add(new Problem(this.GetResolution(type.FullName)));
                }
            }
            return this.Problems;
        }
    }
    
    class AllInterfacesUsedInContractAssembliesShouldImplementIContract : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        private Interface m_IContract;

        public AllInterfacesUsedInContractAssembliesShouldImplementIContract()
            : base("AllInterfacesUsedInContractAssembliesShouldImplementIContract",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(AllInterfacesUsedInContractAssembliesShouldImplementIContract).Assembly)
        {
        }

        public override void BeforeAnalysis()
        {
            m_IContract = TypeNode.GetTypeNode(typeof(System.AddIn.Contract.IContract)) as Interface;
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckContractMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {                    
                    Interface i = type as Interface;
                    if (i != null) // If the type we're checking is an interface.
                    {
                        if (!i.IsAssignableTo(m_IContract)) // If the interface implements IContract.
                        {
                            this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                        }
                    }
                }
            );

            return this.Problems;
        }
    }

    class ContractAssembliesShouldNotUseTypesThatDeriveFromMarshalByRefObject : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ContractAssembliesShouldNotUseTypesThatDeriveFromMarshalByRefObject()
            : base("ContractAssembliesShouldNotUseTypesThatDeriveFromMarshalByRefObject",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldNotUseTypesThatDeriveFromMarshalByRefObject).Assembly)
        {
        }
        
        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckContractMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    if (type.IsAssignableTo(SystemTypes.MarshalByRefObject))
                    {
                        this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                    }
                }
            );

            return this.Problems;
        }
    }
        
    class ContractAssembliesShouldOnlyUseTypesThatAreEitherSerializableOrAreInterfacesImplementingIContract : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ContractAssembliesShouldOnlyUseTypesThatAreEitherSerializableOrAreInterfacesImplementingIContract()
            : base("ContractAssembliesShouldOnlyUseTypesThatAreEitherSerializableOrAreInterfacesImplementingIContract",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldOnlyUseTypesThatAreEitherSerializableOrAreInterfacesImplementingIContract).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckContractMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    // We don't check to see if the interface implements IContract because we have another rule 
                    // that ensures all interfaces implement IContract.
                    // We also ignore arrays since they are checked by another rule
                    if (!type.IsSerializable() && !(type is Interface) && !(type is ArrayType))
                    {
                        this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                    }
                }
            );

            return this.Problems;
        }
    }
    
    class ArraysShouldNotContainTypesThatImplementIContract : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        private Interface m_IContract;

        public ArraysShouldNotContainTypesThatImplementIContract()
            : base("ArraysShouldNotContainTypesThatImplementIContract",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ArraysShouldNotContainTypesThatImplementIContract).Assembly)
        {
        }

        public override void BeforeAnalysis()
        {
            m_IContract = TypeNode.GetTypeNode(typeof(System.AddIn.Contract.IContract)) as Interface;
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckContractMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    ArrayType arrayType = type as ArrayType;
                    if (arrayType != null)
                    {
                        TypeNode elementType = arrayType.ElementType;
                        if (elementType.IsAssignableTo(m_IContract))
                        {
                            this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                        }
                    }
                }
            );

            return this.Problems;
        }
    }
    
    class ArraysShouldOnlyContainSerializableTypes : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        private Interface m_IContract;

        public ArraysShouldOnlyContainSerializableTypes()
            : base("ArraysShouldOnlyContainSerializableTypes",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ArraysShouldOnlyContainSerializableTypes).Assembly)
        {
        }

        public override void BeforeAnalysis()
        {
            m_IContract = TypeNode.GetTypeNode(typeof(System.AddIn.Contract.IContract)) as Interface;
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckContractMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    ArrayType arrayType = type as ArrayType;
                    if (arrayType != null)
                    {
                        // IContract is a special case
                        TypeNode elementType = arrayType.ElementType;
                        if (!elementType.IsSerializable() && !elementType.IsAssignableTo(m_IContract))
                        {
                            this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                        }
                    }
                }
            );

            return this.Problems;
        }
    }

    class ContractAssembliesShouldNotContainAnyStaticMembers : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ContractAssembliesShouldNotContainAnyStaticMembers()
            : base("ContractAssembliesShouldNotContainAnyStaticMembers",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldNotContainAnyStaticMembers).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            Method m = member as Method;
            Field f = member as Field;
            Property p = member as Property;

            if ((m != null && m.IsStatic && !(m.DeclaringMember is Property)) // Ignore property accessor methods, since we'll warn on the property anyway.
                || (f != null && f.IsStatic)
                || (p != null && p.IsStatic))
            {
                this.Problems.Add(new Problem(this.GetResolution(member.FullName)));
            }

            return this.Problems;
        }
    }

    class ContractAssembliesShouldNotDefineEvents : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ContractAssembliesShouldNotDefineEvents()
            : base("ContractAssembliesShouldNotDefineEvents",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldNotDefineEvents).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            if (member is Event)
            {
                this.Problems.Add(new Problem(this.GetResolution(member.FullName)));
            }

            return this.Problems;
        }
    }

    class ContractAssembliesShouldNotUseDelegates : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ContractAssembliesShouldNotUseDelegates()
            : base("ContractAssembliesShouldNotUseDelegates",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldNotUseDelegates).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckContractMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    if (type.IsAssignableTo(SystemTypes.Delegate))
                    {
                        this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                    }
                }
            );

            return this.Problems;
        }
    }
    
    class ContractAssembliesShouldNotUseArbitraryTypesThatImplementICollectionGenericOrICollection : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ContractAssembliesShouldNotUseArbitraryTypesThatImplementICollectionGenericOrICollection()
            : base("ContractAssembliesShouldNotUseArbitraryTypesThatImplementICollectionGenericOrICollection",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldNotUseArbitraryTypesThatImplementICollectionGenericOrICollection).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckContractMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    // We check arrays separately, in their own rules.
                    if (!(type is ArrayType) && 
                        (type.IsAssignableTo(SystemTypes.ICollection) || type.IsAssignableToInstanceOf(SystemTypes.GenericICollection)))
                    {
                        this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                    }
                }
            );

            return this.Problems;
        }
    }

    class ContractAssembliesShouldNotUseATypeDefinedSimplyAsSystemObject : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ContractAssembliesShouldNotUseATypeDefinedSimplyAsSystemObject()
            : base("ContractAssembliesShouldNotUseATypeDefinedSimplyAsSystemObject",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldNotUseATypeDefinedSimplyAsSystemObject).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckContractMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    if (type == SystemTypes.Object)
                    {
                        this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                    }
                }
            );

            return this.Problems;
        }
    }    
    
    class ContractAssembliesShouldNotUseSystemType : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ContractAssembliesShouldNotUseSystemType()
            : base("ContractAssembliesShouldNotUseSystemType",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldNotUseSystemType).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckContractMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    if (type == SystemTypes.Type)
                    {
                        this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                    }
                }
            );

            return this.Problems;
        }
    }
    
    class ContractAssembliesShouldNotUseTypesFromTheSystemReflectionNamespaceOtherThanAssemblyName : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        private Class m_AssemblyName;

        public ContractAssembliesShouldNotUseTypesFromTheSystemReflectionNamespaceOtherThanAssemblyName()
            : base("ContractAssembliesShouldNotUseTypesFromTheSystemReflectionNamespaceOtherThanAssemblyName",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldNotUseTypesFromTheSystemReflectionNamespaceOtherThanAssemblyName).Assembly)
        {
        }

        public override void BeforeAnalysis()
        {
            m_AssemblyName = TypeNode.GetTypeNode(typeof(System.Reflection.AssemblyName)) as Class;
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckContractMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    // Disallow everything in the System.Reflection and System.Reflection.Emit namespaces
                    // besides the System.Reflection.AssemblyName class.
                    if (type.Namespace.ToString().StartsWith("System.Reflection") &&
                        type != m_AssemblyName)
                    {
                        this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                    }
                }
            );

            return this.Problems;
        }
    }

    
    class ContractAssembliesShouldNotUseSystemAddInContractCollectionsIListContractGeneric : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        private Interface m_Collections_IListContract;
        
        public ContractAssembliesShouldNotUseSystemAddInContractCollectionsIListContractGeneric()
            : base("ContractAssembliesShouldNotUseSystemAddInContractCollectionsIListContractGeneric",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldNotUseSystemAddInContractCollectionsIListContractGeneric).Assembly)
        {
        }

        public override void BeforeAnalysis()
        {
            m_Collections_IListContract = TypeNode.GetTypeNode(typeof(System.AddIn.Contract.Collections.IListContract<>)) as Interface;
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckContractMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    if (type.IsAssignableToInstanceOf(m_Collections_IListContract))
                    {
                        this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                    }
                }
            );

            return this.Problems;
        }
    }
    
    class ContractAssembliesShouldNotUseSystemAddinContractCollections : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        private Interface m_Collections_IListContract;

        public ContractAssembliesShouldNotUseSystemAddinContractCollections()
            : base("ContractAssembliesShouldNotUseSystemAddinContractCollections",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldNotUseSystemAddinContractCollections).Assembly)
        {
        }

        public override void BeforeAnalysis()
        {
            m_Collections_IListContract = TypeNode.GetTypeNode(typeof(System.AddIn.Contract.Collections.IListContract<>)) as Interface;
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckContractMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    // System.AddIn.Contract.Collections.IListContract<> is a special case since it has its own rule.
                    if (type.Namespace.ToString().Equals("System.AddIn.Contract.Collections") && !type.IsAssignableToInstanceOf(m_Collections_IListContract))
                    {
                        this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                    }
                }
            );

            return this.Problems;
        }
    }
    
    class ContractAssembliesShouldNotDeclareNonPublicTypes : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ContractAssembliesShouldNotDeclareNonPublicTypes()
            : base("ContractAssembliesShouldNotDeclareNonPublicTypes",
            "Microsoft.AddIn.FxCopRules.ContractRules.ContractRules",
            typeof(ContractAssembliesShouldNotDeclareNonPublicTypes).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            if (!type.IsPublic)
            {
                this.Problems.Add(new Problem(this.GetResolution(type.FullName)));
            }
            return this.Problems;
        }
    }
}

