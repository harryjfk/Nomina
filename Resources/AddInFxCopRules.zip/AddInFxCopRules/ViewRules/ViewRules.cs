﻿//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//

using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.FxCop.Sdk;
using Microsoft.FxCop.Sdk.Introspection;
using Microsoft.Cci;
using Microsoft.AddIn.FxCopRules;

// 
// For a description of each rule, see the ViewRules.xml file.
// 
namespace Microsoft.AddIn.FxCopRules.ViewRules
{
    class ActivatableAddInTypesShouldBeMarkedWithTheAddinBaseAttribute : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        private TypeNode m_ViewAttribute;

        public ActivatableAddInTypesShouldBeMarkedWithTheAddinBaseAttribute()
            : base("ActivatableAddInTypesShouldBeMarkedWithTheAddinBaseAttribute",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(ActivatableAddInTypesShouldBeMarkedWithTheAddinBaseAttribute).Assembly)
        {
        }

        public override void BeforeAnalysis()
        {
            m_ViewAttribute = TypeNode.GetTypeNode(typeof(System.AddIn.Pipeline.AddInBaseAttribute));
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Module module)
        {
            bool hasAttribute = false;
            foreach (TypeNode type in module.Types)
            {
                // Limiting search to interfaces and abstract classes only.
                if (type is Interface || ((type is Class) && type.IsAbstract))
                {
                    foreach (AttributeNode attribute in type.Attributes)
                    {
                        if (attribute.Type == m_ViewAttribute)
                        {
                            hasAttribute = true;
                        }
                    }
                }
            }

            if (!hasAttribute)
            {
                this.Problems.Add(new Problem(this.GetResolution()));
            }

            return this.Problems;
        }
    }
    
    class ConcreteReferenceTypesShouldDeriveFromAViewTypeDefinedInTheCurrentAssembly : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ConcreteReferenceTypesShouldDeriveFromAViewTypeDefinedInTheCurrentAssembly()
            : base("ConcreteReferenceTypesShouldDeriveFromAViewTypeDefinedInTheCurrentAssembly",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(ConcreteReferenceTypesShouldDeriveFromAViewTypeDefinedInTheCurrentAssembly).Assembly)
        {
        }
        
        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            if (type.IsConcreteReferenceType())
            {
                if (!type.ImplementsInterfaceIn(type.DeclaringModule.ContainingAssembly) &&
                    !type.InheritsAbstractClassFrom(type.DeclaringModule.ContainingAssembly))
                {   
                    this.Problems.Add(new Problem(this.GetResolution(type.FullName)));
                }
            }
            return this.Problems;
        }
    }
        
    class ViewTypesShouldNotImplementIContractOrAnInterfaceThatImplementsIContract : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        private Interface m_IContract;

        public ViewTypesShouldNotImplementIContractOrAnInterfaceThatImplementsIContract()
            : base("ViewTypesShouldNotImplementIContractOrAnInterfaceThatImplementsIContract",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(ViewTypesShouldNotImplementIContractOrAnInterfaceThatImplementsIContract).Assembly)
        {
        }

        public override void BeforeAnalysis()
        {
            m_IContract = TypeNode.GetTypeNode(typeof(System.AddIn.Contract.IContract)) as Interface;
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            if (type.IsAssignableTo(m_IContract))
            {
                    this.Problems.Add(new Problem(this.GetResolution(type.FullName)));
            }
            return this.Problems;
        }
    }
    
    class ViewTypesShouldNotBeMarkedSerializable : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ViewTypesShouldNotBeMarkedSerializable()
            : base("ViewTypesShouldNotBeMarkedSerializable",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(ViewTypesShouldNotBeMarkedSerializable).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            if (type.IsAssignableTo(SystemTypes.ISerializable))
            {
                this.Problems.Add(new Problem(this.GetNamedResolution("Interface", type.FullName)));
            }

            if (type.HasSerializableAttribute())
            {
                this.Problems.Add(new Problem(this.GetNamedResolution("Attribute", type.FullName)));
            }

            return this.Problems;
        }
    }
    
    class ViewTypesShouldNotDeriveFromMarshalByRefObject : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        private Class m_Control;

        public ViewTypesShouldNotDeriveFromMarshalByRefObject()
            : base("ViewTypesShouldNotDeriveFromMarshalByRefObject",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(ViewTypesShouldNotDeriveFromMarshalByRefObject).Assembly)
        {
        }

        public override void BeforeAnalysis()
        {
            m_Control = TypeNode.GetTypeNode(typeof(System.Windows.Forms.Control)) as Class;
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            if (type.IsAssignableTo(SystemTypes.MarshalByRefObject) && 
                !(type.IsAssignableTo(m_Control)))
            {
                this.Problems.Add(new Problem(this.GetResolution(type.FullName)));
            }

            return this.Problems;
        }
    }
    
    class ViewTypesShouldNotHaveGenericParameters : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ViewTypesShouldNotHaveGenericParameters()
            : base("ViewTypesShouldNotHaveGenericParameters",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(ViewTypesShouldNotHaveGenericParameters).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            if (type.IsGeneric)
            {
                this.Problems.Add(new Problem(this.GetResolution(type.ToString())));
            }
            return this.Problems;
        }
    }
    
    class ThereShouldBeNoExceptionTypesDefinedInTheViewAssembly : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ThereShouldBeNoExceptionTypesDefinedInTheViewAssembly()
            : base("ThereShouldBeNoExceptionTypesDefinedInTheViewAssembly",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(ThereShouldBeNoExceptionTypesDefinedInTheViewAssembly).Assembly)
        {
        }
        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            if (type.IsAssignableTo(SystemTypes.Exception))
            {
                this.Problems.Add(new Problem(this.GetResolution(type.FullName)));
            }
            return this.Problems;
        }
    }
    
    class ViewTypesShouldNotBeMarkedStatic : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ViewTypesShouldNotBeMarkedStatic()
            : base("ViewTypesShouldNotBeMarkedStatic",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(ViewTypesShouldNotBeMarkedStatic).Assembly)
        {
        }

        public override ProblemCollection Check(Module module)
        {
            // The Check(TypeNode) override doesn't visit some static classes.
            // Therefore we use the VisitTypeNode override.
            this.VisitModule(module); // Start "visit" on the module. This will visit all types on the module.
            return this.Problems;
        }

        public override TypeNode VisitTypeNode(TypeNode typeNode)
        {
            // Static classes are sealed and abstract, so we use this check. 
            // IsStatic doesn't work on TypeNode like we need it to.
            if (typeNode.IsSealed && typeNode.IsAbstract)
            {
                this.Problems.Add(new Problem(this.GetResolution(typeNode.FullName)));
            }
            return base.VisitTypeNode(typeNode);
        }
    }
    
    class ViewTypesShouldNotInheritFromFrameworkElement : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        private Class m_FrameworkElement;

        public ViewTypesShouldNotInheritFromFrameworkElement()
            : base("ViewTypesShouldNotInheritFromFrameworkElement",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(ViewTypesShouldNotInheritFromFrameworkElement).Assembly)
        {
        }

        public override void BeforeAnalysis()
        {
            m_FrameworkElement = TypeNode.GetTypeNode(typeof(System.Windows.FrameworkElement)) as Class;
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            if (type.IsAssignableTo(m_FrameworkElement))
            {
                this.Problems.Add(new Problem(this.GetResolution(type.FullName)));
            }
            return this.Problems;
        }
    }
        
    class ViewTypesShouldNotInheritFromControl : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        private Class m_Control;
        
        public ViewTypesShouldNotInheritFromControl()
            : base("ViewTypesShouldNotInheritFromControl",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(ViewTypesShouldNotInheritFromControl).Assembly)
        {
        }

        public override void BeforeAnalysis()
        {
            m_Control = TypeNode.GetTypeNode(typeof(System.Windows.Forms.Control)) as Class;
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.TypeNode type)
        {
            if (type.IsAssignableTo(m_Control))
            {
                this.Problems.Add(new Problem(this.GetResolution(type.FullName)));
            }
            return this.Problems;
        }
    }
    
    class TypesUsedInViewsShouldNotImplementIContract : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        private Interface m_IContract;

        public TypesUsedInViewsShouldNotImplementIContract()
            : base("TypesUsedInViewsShouldNotImplementIContract",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(TypesUsedInViewsShouldNotImplementIContract).Assembly)
        {
        }

        public override void BeforeAnalysis()
        {
            m_IContract = TypeNode.GetTypeNode(typeof(System.AddIn.Contract.IContract)) as Interface;
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckViewMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    if (type.IsAssignableTo(m_IContract))
                    {
                        this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                    }
                }
            );

            return this.Problems;
        }
    }
    
    class ConcreteReferenceTypesUsedInViewsShouldBeSerializable : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ConcreteReferenceTypesUsedInViewsShouldBeSerializable()
            : base("ConcreteReferenceTypesUsedInViewsShouldBeSerializable",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(ConcreteReferenceTypesUsedInViewsShouldBeSerializable).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckViewMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    if(type.IsConcreteReferenceType() && 
                        !type.IsSerializable())
                    {
                        this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                    }
                }
            );

            return this.Problems;
        }
    }
    
    class ConcreteReferenceTypesUsedInViewsShouldBelongToAFrameworkAssembly : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ConcreteReferenceTypesUsedInViewsShouldBelongToAFrameworkAssembly()
            : base("ConcreteReferenceTypesUsedInViewsShouldBelongToAFrameworkAssembly",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(ConcreteReferenceTypesUsedInViewsShouldBelongToAFrameworkAssembly).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckViewMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    if (type.IsConcreteReferenceType() && !type.DeclaringModule.ContainingAssembly.IsFrameworkAssembly())
                    {
                        this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                    }
                }
            );

            return this.Problems;
        }
    }
    
    class EventsShouldBeOfTheGenericTypeEventHandler : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        private DelegateNode m_EventHandlerGeneric;
        
        public EventsShouldBeOfTheGenericTypeEventHandler()
            : base("EventsShouldBeOfTheGenericTypeEventHandler",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(EventsShouldBeOfTheGenericTypeEventHandler).Assembly)
        {
        }

        public override void BeforeAnalysis()
        {
            m_EventHandlerGeneric = TypeNode.GetTypeNode(typeof(System.EventHandler<>)) as DelegateNode;
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            Event e = member as Event;
            if (e != null)
            {
                if (!e.HandlerType.IsAssignableToInstanceOf(m_EventHandlerGeneric))
                {
                    this.Problems.Add(new Problem(this.GetResolution(e.FullName)));
                }
            }

            return this.Problems;
        }
    }
    
    class EventsShouldOnlyBeDeclaredOnInterfaces : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public EventsShouldOnlyBeDeclaredOnInterfaces()
            : base("EventsShouldOnlyBeDeclaredOnInterfaces",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(EventsShouldOnlyBeDeclaredOnInterfaces).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            // Ensure events are not declared on abstract base classes.
            Event e = member as Event;
            if (e != null)
            {
                Class c = e.DeclaringType as Class;
                if (c != null && c.IsAbstract)
                {
                    this.Problems.Add(new Problem(this.GetResolution(e.FullName)));
                }
            }
            return this.Problems;
        }
    }

    class ViewArraysShouldOnlyContainSerializableTypes : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ViewArraysShouldOnlyContainSerializableTypes()
            : base("ViewArraysShouldOnlyContainSerializableTypes",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(ViewArraysShouldOnlyContainSerializableTypes).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {            
            member.CheckViewMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    ArrayType arrayType = type as ArrayType;
                    if(arrayType != null)
                    {
                        if (!arrayType.ElementType.IsSerializable())
                        {
                            this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                        }
                    }
                }
            );

            return this.Problems;
        }
    }

    class IListGenericShouldBeUsedInsteadOfArbitraryICollections : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public IListGenericShouldBeUsedInsteadOfArbitraryICollections()
            : base("IListGenericShouldBeUsedInsteadOfArbitraryICollections",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(IListGenericShouldBeUsedInsteadOfArbitraryICollections).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckViewMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    // Allow arrays as a special case.
                    if (!(type is ArrayType))
                    {
                        if (type.IsAssignableTo(SystemTypes.ICollection) || type.IsAssignableToInstanceOf(SystemTypes.GenericICollection))
                        {
                            this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                        }
                    }
                }
            );

            return this.Problems;
        }
    }

    class NonConcreteTypesUsedInViewsShouldBeDefinedInTheViewAssembly : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public NonConcreteTypesUsedInViewsShouldBeDefinedInTheViewAssembly()
            : base("NonConcreteTypesUsedInViewsShouldBeDefinedInTheViewAssembly",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(NonConcreteTypesUsedInViewsShouldBeDefinedInTheViewAssembly).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckViewMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    // This rule applies to abstract classes and interfaces only.
                    if (((type is Class) && type.IsAbstract) ||
                        (type is Interface))
                    {
                        if (type.DeclaringModule.ContainingAssembly != member.DeclaringType.DeclaringModule.ContainingAssembly)
                        {
                            this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                        }
                    }
                }
            );

            return this.Problems;
        }
    }
    
    class SerializableTypesUsedByViewsShouldBeDefinedInAFrameworkAssembly : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public SerializableTypesUsedByViewsShouldBeDefinedInAFrameworkAssembly()
            : base("SerializableTypesUsedByViewsShouldBeDefinedInAFrameworkAssembly",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(SerializableTypesUsedByViewsShouldBeDefinedInAFrameworkAssembly).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckViewMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    if (type.IsSerializable() && 
                        type.DeclaringModule.ContainingAssembly != member.DeclaringType.DeclaringModule.ContainingAssembly && 
                        !type.DeclaringModule.ContainingAssembly.IsFrameworkAssembly())
                    {
                        this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                    }
                }
            );

            return this.Problems;
        }
    }
    
    class ViewMembersShouldNotHaveOpenGenericParameters : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ViewMembersShouldNotHaveOpenGenericParameters()
            : base("ViewMembersShouldNotHaveOpenGenericParameters",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(ViewMembersShouldNotHaveOpenGenericParameters).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            Method method = member as Method;
            if (method != null && method.IsGeneric)
            {
                this.Problems.Add(new Problem(this.GetResolution(member.FullName)));
            }

            return this.Problems;
        }
    }
    
    class ViewsShouldNotUseATypeDefinedSimplyAsSystemObject : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ViewsShouldNotUseATypeDefinedSimplyAsSystemObject()
            : base("ViewsShouldNotUseATypeDefinedSimplyAsSystemObject",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(ViewsShouldNotUseATypeDefinedSimplyAsSystemObject).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            member.CheckViewMemberProblems(
                delegate(string resolutionName, string memberName, TypeNode type)
                {
                    if(type == SystemTypes.Object)
                    {
                        this.Problems.Add(new Problem(this.GetNamedResolution(resolutionName, memberName, type.Name.ToString())));
                    }
                }
            );

            return this.Problems;
        }
    }
    
    class ViewMembersShouldNotBeMarkedStatic : Microsoft.FxCop.Sdk.Introspection.BaseIntrospectionRule
    {
        public ViewMembersShouldNotBeMarkedStatic()
            : base("ViewMembersShouldNotBeMarkedStatic",
            "Microsoft.AddIn.FxCopRules.ViewRules.ViewRules",
            typeof(ViewMembersShouldNotBeMarkedStatic).Assembly)
        {
        }

        public override Microsoft.FxCop.Sdk.Introspection.ProblemCollection Check(Microsoft.Cci.Member member)
        {
            Field f = member as Field;

            // Disallow static fields only. Methods are fine.
            if (f != null && f.IsStatic)
            {
                this.Problems.Add(new Problem(this.GetResolution(member.FullName)));
            }

            return this.Problems;
        }
    }
}
